"use client";

export const NewVerificationForm = () => {
    return <div></div>;
};
