"use client";

export const ResetForm = () => {
    return <div></div>;
};
