import { ErrorCard } from '@/components/auth/error-card'

const AuthErrorPage = () => {
    return <ErrorCard />
}

export default AuthErrorPage
