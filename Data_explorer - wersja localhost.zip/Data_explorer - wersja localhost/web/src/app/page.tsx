const Page = async () => {
    return (
        <div className="flex justify-center items-center w-full">
            <div className="w-8/10 items-start justify-start flex bg-black flex-col ">
                <div className="text-white p-5 text-2xl font-bold ">
                    Dashboard
                </div>
            </div>
        </div>
    );
};

export default Page;
